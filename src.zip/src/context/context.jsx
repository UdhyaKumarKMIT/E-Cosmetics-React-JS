"use client"

import { createContext, useState, useContext } from "react"

// Create context
const ShopContext = createContext()

// Sample cosmetics products data
const products = [
  {
    id: 1,
    name: "Hydrating Face Cream",
    price: 24.99,
    image: "cream1.png",
    category: "skincare",
    featured: true,
    description: "A deeply hydrating face cream that nourishes and revitalizes your skin.",
  },
  {
    id: 2,
    name: "Volumizing Mascara",
    price: 19.99,
    image: "mascara1.png",
    category: "makeup",
    featured: true,
    description: "Get fuller, longer lashes with our volumizing mascara formula.",
  },
  {
    id: 3,
    name: "Matte Lipstick",
    price: 15.99,
    image: "lipstick1.png",
    category: "makeup",
    featured: true,
    description: "Long-lasting matte lipstick that doesn't dry out your lips.",
  },
  {
    id: 4,
    name: "Vitamin C Serum",
    price: 29.99,
    image: "serum1.png",
    category: "skincare",
    featured: false,
    description: "Brighten your complexion with our powerful Vitamin C serum.",
  },
  {
    id: 5,
    name: "Exfoliating Scrub",
    price: 18.99,
    image: "scrub1.png",
    category: "skincare",
    featured: false,
    description: "Gentle exfoliating scrub to remove dead skin cells and reveal glowing skin.",
  },
  {
    id: 6,
    name: "Foundation",
    price: 32.99,
    image: "foundation1.png",
    category: "makeup",
    featured: true,
    description: "Medium to full coverage foundation with a natural finish.",
  },
  {
    id: 7,
    name: "Eye Shadow Palette",
    price: 39.99,
    image: "eyeshadow1.png",
    category: "makeup",
    featured: false,
    description: "12 highly pigmented eyeshadow colors for creating endless looks.",
  },
  {
    id: 8,
    name: "Cleansing Oil",
    price: 22.99,
    image: "cleanser1.png",
    category: "skincare",
    featured: false,
    description: "Gentle cleansing oil that removes makeup and impurities without stripping the skin.",
  },
]

export const ShopProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([])
  const [user, setUser] = useState(null)

  // Add to cart
  const addToCart = (product) => {
    const existingItem = cartItems.find((item) => item.id === product.id)

    if (existingItem) {
      setCartItems(cartItems.map((item) => (item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item)))
    } else {
      setCartItems([...cartItems, { ...product, quantity: 1 }])
    }
  }

  // Remove from cart
  const removeFromCart = (productId) => {
    const existingItem = cartItems.find((item) => item.id === productId)

    if (existingItem.quantity === 1) {
      setCartItems(cartItems.filter((item) => item.id !== productId))
    } else {
      setCartItems(cartItems.map((item) => (item.id === productId ? { ...item, quantity: item.quantity - 1 } : item)))
    }
  }

  // Clear cart
  const clearCart = () => {
    setCartItems([])
  }

  // Login user
  const login = (userData) => {
    setUser(userData)
  }

  // Logout user
  const logout = () => {
    setUser(null)
  }

  // Calculate cart total
  const getCartTotal = () => {
    return cartItems.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  // Get cart items count
  const getCartCount = () => {
    return cartItems.reduce((count, item) => count + item.quantity, 0)
  }

  return (
    <ShopContext.Provider
      value={{
        products,
        cartItems,
        user,
        addToCart,
        removeFromCart,
        clearCart,
        login,
        logout,
        getCartTotal,
        getCartCount,
      }}
    >
      {children}
    </ShopContext.Provider>
  )
}

// Custom hook to use the shop context
export const useShop = () => {
  return useContext(ShopContext)
}
