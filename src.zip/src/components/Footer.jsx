import { Container, Row, Col, Form, Button, InputGroup } from "react-bootstrap"
import { Link } from "react-router-dom"
import { FaFacebookF, FaTwitter, FaInstagram, FaPinterestP, FaYoutube, FaPaperPlane } from "react-icons/fa"

const Footer = () => {
  return (
    <footer className="bg-dark text-white pt-5 pb-3">
      <Container>
        <Row className="mb-5">
          <Col lg={3} md={6} className="mb-4 mb-lg-0">
            <h5 className="mb-4 fw-bold">GlowUp Cosmetics</h5>
            <p className="mb-4">
              Premium cosmetics that enhance your natural beauty while being kind to your skin and the planet.
            </p>
            <div className="d-flex gap-3 social-icons">
              <a href="https://facebook.com" className="text-white" aria-label="Facebook">
                <FaFacebookF size={18} />
              </a>
              <a href="https://twitter.com" className="text-white" aria-label="Twitter">
                <FaTwitter size={18} />
              </a>
              <a href="https://instagram.com" className="text-white" aria-label="Instagram">
                <FaInstagram size={18} />
              </a>
              <a href="https://pinterest.com" className="text-white" aria-label="Pinterest">
                <FaPinterestP size={18} />
              </a>
              <a href="https://youtube.com" className="text-white" aria-label="YouTube">
                <FaYoutube size={18} />
              </a>
            </div>
          </Col>

          <Col lg={3} md={6} className="mb-4 mb-lg-0">
            <h5 className="mb-4 fw-bold">Quick Links</h5>
            <ul className="list-unstyled footer-links">
              <li className="mb-2">
                <Link to="/" className="text-white text-decoration-none">
                  Home
                </Link>
              </li>
              <li className="mb-2">
                <Link to="/products" className="text-white text-decoration-none">
                  Shop
                </Link>
              </li>
              <li className="mb-2">
                <Link to="/about" className="text-white text-decoration-none">
                  About Us
                </Link>
              </li>
              <li className="mb-2">
                <Link to="/contact" className="text-white text-decoration-none">
                  Contact
                </Link>
              </li>
              <li className="mb-2">
                <Link to="/login" className="text-white text-decoration-none">
                  Login
                </Link>
              </li>
            </ul>
          </Col>

          <Col lg={3} md={6} className="mb-4 mb-lg-0">
            <h5 className="mb-4 fw-bold">Customer Service</h5>
            <ul className="list-unstyled footer-links">
              <li className="mb-2">
                <Link to="/faq" className="text-white text-decoration-none">
                  FAQ
                </Link>
              </li>
              <li className="mb-2">
                <Link to="/shipping" className="text-white text-decoration-none">
                  Shipping & Returns
                </Link>
              </li>
              <li className="mb-2">
                <Link to="/terms" className="text-white text-decoration-none">
                  Terms & Conditions
                </Link>
              </li>
              <li className="mb-2">
                <Link to="/privacy" className="text-white text-decoration-none">
                  Privacy Policy
                </Link>
              </li>
              <li className="mb-2">
                <Link to="/track-order" className="text-white text-decoration-none">
                  Track Order
                </Link>
              </li>
            </ul>
          </Col>

          <Col lg={3} md={6}>
            <h5 className="mb-4 fw-bold">Newsletter</h5>
            <p className="mb-4">Subscribe to our newsletter for exclusive offers and beauty tips.</p>
            <Form>
              <InputGroup className="mb-3">
                <Form.Control
                  placeholder="Your email address"
                  aria-label="Your email address"
                  aria-describedby="newsletter-button"
                />
                <Button variant="primary" id="newsletter-button">
                  <FaPaperPlane />
                </Button>
              </InputGroup>
            </Form>
          </Col>
        </Row>

        <hr className="my-4 bg-secondary" />

        <Row>
          <Col className="text-center">
            <p className="small text-muted mb-0">
              &copy; {new Date().getFullYear()} GlowUp Cosmetics. All rights reserved.
            </p>
          </Col>
        </Row>
      </Container>
    </footer>
  )
}

export default Footer
